# picture-travel


## Overview
 The idea of this picture-travel Application is user can add many pins on the map then when click on any pin it will open another page , if the location has a photos on Flickr website it will download the photos and display them on CollectionView and also save it on Coredata , if there is no photos it will display a message "no photo" . user also can remove any photo by click on it and tap a delete button . also use can download new collection . and becuase photos saved on coreData if the app closed and re-open the photo will display immediately without need to download it again . 
## Specification
picture-travel is built and tested for the following software versions:
* Xcode 10.1
*  Universal (Ipone, Ipad )
* Swift 4

# This project focused on working with Data Persistence (CoreData)
- Working with UserDefult
- The Coredata Stack
- NSFetchedResultsController
- Mapkit

# Accounts:
[linked In ](www.linkedin.com/in/shaimaa-alghamdi)
[GitHub](https://github.com/shaimaa-alghamdi)
[Send Email to Shaimaa Alghamdi](shyom.1417@gmail.com)

