//
//  exrta.swift
//  fpicture-travel
//
//  Created by شيما on 27/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation
import UIKit

//MARK: Alert Func .


struct Alert {
    
    static func Alert(message: String, title: String, vc: UIViewController)
    {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let OKAction = UIAlertAction(title: "ok", style: .default, handler: nil)
        alertController.addAction(OKAction)
        
        vc.present(alertController, animated: true, completion: nil)
        
    }
    
}
struct randomPage {
    static func randomPageNumber() -> Int {
        return Int.random(in: 0 ... 10)
    }
}

