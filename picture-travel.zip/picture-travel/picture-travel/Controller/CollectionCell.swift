//
//  CollectionCell.swift
//  picture-travel
//
//  Created by شيما on 19/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class CollectionCell: UICollectionViewCell {
    
    
    @IBOutlet weak var Activity: UIActivityIndicatorView!
    
    
    @IBOutlet weak var image: UIImageView!
    
 
    
}
