//
//  DataController.swift
//  picture-travel
//
//  Created by شيما on 19/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import CoreData
class DataController {
    let persistentContainer: NSPersistentContainer
    
    var viewContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    var backgroundContext: NSManagedObjectContext!
    
    init(modelName: String){
        persistentContainer = NSPersistentContainer(name: modelName)
    }
    
    func configureContext(){
        backgroundContext = persistentContainer.newBackgroundContext()
        
        viewContext.automaticallyMergesChangesFromParent = true
        backgroundContext.automaticallyMergesChangesFromParent = true
        
        backgroundContext.mergePolicy = NSMergePolicy.mergeByPropertyObjectTrump
        viewContext.mergePolicy = NSMergePolicy.mergeByPropertyStoreTrump
    }
    
    func load(completionHandler: (() -> Void)? = nil) {
        persistentContainer.loadPersistentStores { (description, error) in
            guard error == nil else{
                print("Persistence Stor Load Error")
                fatalError(error!.localizedDescription)
            }
            print("DataController loaded")
            self.configureContext()
            completionHandler?()
        }
    }
}
