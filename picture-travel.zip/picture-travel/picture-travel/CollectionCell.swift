//
//  CollectionCell.swift
//  Virtual-Tourist
//
//  Created by شيما on 19/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//


import UIKit

class Collec: UICollectionViewCell{

    
    
    
    
    
    
}
